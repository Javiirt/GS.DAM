/*CREATE OR REPLACE VIEW EMPLEADOCOMPLETO AS (SELECT ENAME, EMPNO, SAL, COMM, (SAL+COMM) AS SALARIO_TOTAL FROM EMP WHERE COMM>0);


SELECT * FROM EMPLEADOCOMPLETO;*/



/*CREATE or REPLACE VIEW EmpleadoDEPT AS (SELECT EMPNO NUMERO, ENAME NOMBREEMPLEADO, SAL SALARIO, (SAL+COMM) AS SALARIO_TOTAL, DNAME NOMBREDEPARTAMENTO, LOC LOCALIDADDEPARTAMENTO FROM EMP JOIN DEPT ON DEPT.DEPTNO=EMP.DEPTNO);


SELECT * FROM EmpleadoDEPT;*/



/*1 Crea una vista de los empleados con su antigúedad, numero empleado y nombre*/

CREATE VIEW EmpleadoconAntiguedad AS (select trunc((SYSDATE-HIREDATE)/365) antiguedad, EMPNO numero, ENAME Nombre from EMP);

select * from EmpleadoconAntiguedad order by ANTIGÜEDAD;

/*SELECT ENAME, trunc((SYSDATE-HIREDATE)/365) from EMP;*

/*2 Crea una vista de los empleados  el grado de salario y su jefe (nombre). (numero empleado y nombre)*/


CREATE VIEW EmpleadoconJefe AS (SELECT e1.ENAME NOMEMPLE, e1.EMPNO NUMERO, GRADE, e2.ENAME NOMJEFE FROM SALGRADE, EMP e1, EMP e2 WHERE e2.EMPNO=e1.MGR AND LOSAL<e1.SAL AND HISAL>e1.SAL);

/*3 Crea una vista de los empleados (numero empleado y nombre)  en lugar de mostrar el departamento al que pertenece muestra el de su jefe su jefe.*/

SELECT e1.ENAME NOMEMPLE, e1.EMPNO NUMERO, GRADE, e2.ENAME NOMJEFE FROM SALGRADE, EMP e1, EMP e2 WHERE e2.EMPNO=e1.MGR AND LOSAL<e1.SAL AND HISAL>e1.SAL


/*4 crear vista con nombre departamento y número de empleados*/


