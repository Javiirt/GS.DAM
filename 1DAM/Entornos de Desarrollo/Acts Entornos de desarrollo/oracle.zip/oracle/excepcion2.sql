

DECLARE


N_DORSAL NUMBER(9,2);
N_partenombre VARCHAR2(50);

BEGIN
N_partenombre:='%&DATO%';
SELECT dorsal INTO N_DORSAL FROM CICLISTA WHERE nombre LIKE N_partenombre;

UPDATE ETAPA SET dorsaL=N_DORSAL WHERE netapa=1; 

EXCEPTION

        WHEN TOO_MANY_ROWS THEN
/*
		DBMS_OUTPUT.PUT_LINE('No se puede almacenar mas de una fila') ;   
*/
	SELECT MAX(dorsal) INTO N_DORSAL FROM CICLISTA WHERE nombre LIKE N_partenombre;
	UPDATE ETAPA SET dorsaL=N_DORSAL WHERE netapa=1;


	WHEN NO_DATA_FOUND THEN
		DBMS_OUTPUT.PUT_LINE('No hay ningun dato registrado') ;   




END;

