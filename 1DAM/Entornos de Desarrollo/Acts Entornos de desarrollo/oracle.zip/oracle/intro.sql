select JOB from  EMP where DEPTNO=&dato;
