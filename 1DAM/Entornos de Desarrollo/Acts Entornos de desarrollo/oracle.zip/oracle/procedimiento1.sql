CREATE OR REPLACE PROCEDURE EJERC1 (numero1 number, numero2 number)
IS
BEGIN
DBMS_OUTPUT.PUT_LINE(numero1+numero2);
end;

DECLARE
y number:=3;
BEGIN
ejerc1(1,y);
end;
