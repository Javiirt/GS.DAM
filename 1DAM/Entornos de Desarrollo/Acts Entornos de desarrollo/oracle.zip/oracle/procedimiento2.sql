CREATE OR REPLACE PROCEDURE EJERC2(n1 number, n2 number, n3 OUT number)
IS
BEGIN
n3:=n1+n2;
end;

DECLARE
resultado number:=0;
BEGIN
EJERC2(1, 3, resultado);
dbms_output.put_line(resultado);
end; 
