CREATE OR REPLACE PROCEDURE EJERC3(n1 IN OUT number, n2 IN number)
IS
BEGIN
n1:=n1+n2;
end;

DECLARE
n3 number:=5;
n4 number:=7;
BEGIN
EJERC3(N3, N4);
dbms_output.put_line(N3);
end; 
