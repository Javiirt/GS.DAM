CREATE OR REPLACE PROCEDURE EJERC8(nEmp number)
IS

BEGIN
DELETE FROM EMP WHERE EMPNO=nEmp;
end;

DECLARE

n_numero number;

BEGIN
n_numero:=&dato;
EJERC8(n_numero);
END;
