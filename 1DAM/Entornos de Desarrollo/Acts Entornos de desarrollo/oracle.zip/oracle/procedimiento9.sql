CREATE OR REPLACE PROCEDURE EJERC9(ndepart number, nlocalidad varchar2)
IS

BEGIN
UPDATE DEPART SET LOC=nlocalidad WHERE DEPT_NO=ndepart;

end;

DECLARE

num_depart number;
nom_localidad varchar2(50);

BEGIN
num_depart:=&NUMERODEPARTAMENTO;
nom_localidad:='&LOCALIDAD';

EJERC9(num_depart, nom_localidad);

END;
