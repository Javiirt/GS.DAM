CREATE OR REPLACE PROCEDURE 
escribir(numero Integer) 
IS
BEGIN
numero:=2;
DBMS_OUTPUT.PUT_LINE(numero);

vdato Number:=0;
BEGIN
escribir(vdato)
DBMS_OUTPUT.PUT_LINE(2);
