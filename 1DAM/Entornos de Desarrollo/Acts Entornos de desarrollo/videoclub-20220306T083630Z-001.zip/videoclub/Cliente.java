package videoclub;
import java.util.ArrayList;
import java.util.List;

public class Cliente {

    private String nombre;
    private List<Alquiler> alquileres = new ArrayList<Alquiler>();

    public Cliente(String nombre) {
        this.nombre = nombre;
    }

    public void agregarAlquiler(Alquiler arg) {
        alquileres.add(arg);
    }

    public String getNombre() {
        return nombre;
    }

    public String extracto() {
        double importeTotal = 0;
        int puntosAlquilerFrecuente = 0;
        String resultado = "Alguileres de " + getNombre() + "\n";

        for (Alquiler each: alquileres) {
            double importe = 0;

            //determine amounts for each line
            switch (each.getPelicula().getCodigoPrecio()) {
                case Pelicula.REGULAR:
                    importe += 2;
                    if (each.getDiasAlquilada() > 2)
                        importe += (each.getDiasAlquilada() - 2) * 1.5;
                    break;
                case Pelicula.ESTRENO:
                    importe += each.getDiasAlquilada() * 3;
                    break;
                case Pelicula.INFANTIL:
                    importe += 1.5;
                    if (each.getDiasAlquilada() > 3)
                        importe += (each.getDiasAlquilada() - 3) * 1.5;
                    break;
            }

            // add frequent renter points
            puntosAlquilerFrecuente++;
            // add bonus for a two day new release rental
            if ((each.getPelicula().getCodigoPrecio() == Pelicula.ESTRENO) && each.getDiasAlquilada() > 1)
                puntosAlquilerFrecuente++;

            // show figures for this rental
            resultado += "\t" + each.getPelicula().getTitulo() + "\t" + String.valueOf(importe) + "\n";
            importeTotal += importe;
        }

        // add footer lines
        resultado += "La cantidad adeudada es " + String.valueOf(importeTotal) + "\n";
        resultado += "Has ganado " + String.valueOf(puntosAlquilerFrecuente) + " puntos por alquiler frecuente";

        return resultado;
    }
}