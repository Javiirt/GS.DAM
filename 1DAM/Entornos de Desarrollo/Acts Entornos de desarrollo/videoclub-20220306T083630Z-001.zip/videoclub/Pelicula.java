package videoclub;

public class Pelicula {

    public static final int INFANTIL = 2;
    public static final int ESTRENO = 1;
    public static final int REGULAR = 0;

    private String titulo;
    private int codigoPrecio;

    public Pelicula(String titulo, int codigoPrecio) {
        this.titulo = titulo;
        this.codigoPrecio = codigoPrecio;
    }

    public int getCodigoPrecio() {
        return codigoPrecio;
    }

    public void setCodigoPrecio(int arg) {
        codigoPrecio = arg;
    }
    public String getTitulo() {
        return titulo;
    }


}