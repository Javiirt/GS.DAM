/*Slideshow*/

     var slide= new Array();
    
     slide[0]='slide/uno.png'
     slide[1]='slide/dos.png'
     slide[2]='slide/tres.png'
     
     
    
        var el = document.getElementById("carrusel");
        console.log(el);
        var i=0
        var nuevo=document.createElement('img')
           nuevo.setAttribute('src',slide[i])
            console.log(nuevo)
           el.appendChild(nuevo)
           
               function pasarFoto() {
                
                   if(i< slide.length - 1) {
                        i++;
                       nuevo.setAttribute('src',slide[i]) 
                       console.log(slide[i])
                   } else{  
                       i=0
                        nuevo.setAttribute('src',slide[i]) 
                   }
            }
           
           function atrasFoto() {
                
                   if(i<=0) {
                       i=slide.length-1
                        
                       nuevo.setAttribute('src',slide[i]) 
                       console.log(slide[i])
                   } else{  
                       i--
                        nuevo.setAttribute('src',slide[i])
                       console.log(slide[i])
                   }
            }
               
          