    
/*var videos= new Array();
    
     videos[0]='video/grumeteinicio.mp4'
     videos[1]='video/grumeteok.mp4'
     videos[2]='video/grumetefallo.mp4'
     videos[3]='video/grumetefinal.mp4'*/




        
    $(document).ready(function(){
       $("button").click(function(){
        $("#grumetevideo").hide();
        console.log("hola")
       })
    })








        /*

            
            function quiz(){
        
        var opciones = document.getElementById("1522")

            if(opciones.checked==true){
                
                document.getElementById("nuevos").setAttribute('src',"video/grumeteok.mp4").autoplay()
                

                console.log(nuevo)

                }else{
                document.getElementById("nuevos").src="video/grumetefallo.mp4";
                console.log(nuevo)
                nuevo.load()
                nuevo.play()
                }

                }*/

                 










        