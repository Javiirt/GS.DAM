var agendaNombre = [];
var agendaNumero = [];	

function agenda(){
	do {
		var opcion = prompt('Elige una opción:'+'\n'+'1. Añadir'+'\n'+'2. Borrar'+'\n'+'3. Buscar'+'\n'+'4. Listar'+'\n'+'0. Salir','Ej: 1');	
		
		switch (opcion) {
		
		case '1':
			añadir();
			break;
		
		case '2':
			borrar();
			break;

		case '3':
			buscar();
			break;

		case '4':
			listar();
			break;

		case '0':
			break;

		case null:
			alert('No canceles, para salir introduce 0');
			break;

		default:
			alert('Introduce un número de la lista');
			break
		}
	} while (opcion!=0)
}

function añadir(){
	var nombre = prompt('Nombre del contacto:','Ej: Robert');
	var numero = prompt('Introduce el número del contacto','Ej: 661183266');
	agendaNombre.push(nombre);
	agendaNumero.push(numero);
	alert('Contacto añadido')
}

function borrar(){
	var nombreBuscado = prompt('Contacto a borrar','Ej: Robert');
	var i = 0;

	while((agendaNombre[i] != nombreBuscado) && (i < agendaNombre.length)){
		++i;
	}

	if(agendaNombre[i] == nombreBuscado){
		agendaNombre.splice(i,1);
		agendaNumero.splice(i,1);
		alert('Contacto borrado');
	} else {
		alert('El contacto no existe');
	}
}

function buscar(){
	var nombreBuscado = prompt('Contacto a borrar','Ej: Robert');
	var i = 0;

	while((agendaNombre[i] != nombreBuscado) && (i < agendaNombre.length)){
		++i;
	}

	if(agendaNombre[i] == nombreBuscado){
		alert('El número de ' + agendaNombre[i] + ' es ' + agendaNumero[i]);
	} else {
		alert('El contacto no existe');
	}
}

function listar(){
	for (var i=0;i<agendaNombre.length;i++){
	alert(agendaNombre[i] + ': ' + agendaNumero[i] + "\n");
	}
}

