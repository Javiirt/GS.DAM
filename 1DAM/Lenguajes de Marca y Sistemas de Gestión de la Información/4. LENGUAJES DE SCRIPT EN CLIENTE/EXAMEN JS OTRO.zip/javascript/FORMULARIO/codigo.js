var error = document.getElementById('error');

function enviarFormulario(){
	if(validarFormulario()==true){
		return true;
	}else{
		return false;
	}
}

function validarFormulario(){
	if(validarNombre() == true && validarEdad() == true && validarDNI() == true && validarDireccion() == true &&
	validarCodPostal() == true && validarTel() == true && validarCorreo() == true && validarFecha() == true &&
	validarSeleccion() == true && validarCheckbox() == true && validarRadio() == true){
		return true;
	}else{
		return false;
	}
}

function validarNombre(){
	var nombre = document.getElementById('nombre').value;
	if(nombre == null || nombre.length == 0 || /^\s+$/.test(nombre)){
		error.innerHTML = "Nombre no válido";
		return false;
	}else{
		return true;
	}
}

function validarEdad(){
	var edad = document.getElementById('edad').value;
	if(isNaN(edad) || edad < 18){
		error.innerHTML = "Edad no válida";
		return false;
	}else{
		return true;
	}
}

function validarDNI(){
	var dni = document.getElementById('dni').value;
	var letras = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X',
	'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'];
	if( !(/^\d{8}[A-Z]$/.test(dni)) || dni.charAt(8) != letras[(dni.substring(0, 8))%23] ) {
		error.innerHTML = "DNI no válido";
		return false;
	}else{
		return true;
	}
}

function validarDireccion(){
	var direccion = document.getElementById('direccion').value;
	if(direccion == null || direccion.length == 0 || /^\s+$/.test(direccion)){
		error.innerHTML = "Direccion no válida";
		return false;
	}else{
		return true;
	}
}

function validarCodPostal(){
	var codPostal = document.getElementById('codPostal').value;
	if(isNaN(codPostal) || codPostal < 11001 || codPostal > 11012){
		error.innerHTML = "Código postal no válido";
		return false;
	}else{
		return true;
	}
}

function validarTel(){
	telefono = document.getElementById("telefono").value;
	if( !(/^\d{9}$/.test(telefono)) ) {
		error.innerHTML = "Telefono no válido";
		return false;
	}else{
		return true;
	}
}

function validarCorreo() {
	var correo = document.getElementById('correo').value;
  	if (/^\w+([\.\+\-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(correo)){
   		return true;
  	} else {
   		error.innerHTML = "Correo no válido";
   		return false;
  	}
}

function validarFecha(){
	var fecha = document.getElementById('fecha').value;
    if (/^\d{2}\/\d{2}\/\d{4}$/.test(fecha) && (fecha!='')) {
        return true;
    } else {
    	error.innerHTML = "Fecha no válida";
        return false;
    }
}

function validarSeleccion(){
	indice = document.getElementById("interes").selectedIndex;
	if( indice == null || indice == 0 ) {
		error.innerHTML = "Interés no válido";
		return false;
	}else{
		return true;
	}
}

function validarCheckbox(){
	checkbox = document.getElementById("checkbox");
	if( !checkbox.checked ) {
		error.innerHTML = "Check no válido";
		return false;
	}else{
		return true;
	}
}

function validarRadio(){
	opciones = document.getElementsByName("opciones");
	var seleccionado = false;
	for(var i=0; i<opciones.length; i++) {
		if(opciones[i].checked) {
			seleccionado = true;
			break;
		}
	}
	if(!seleccionado) {
		error.innerHTML = "Radio no válido";
		return false;
	}else{
		return true;
	}
}

function limpiarError(){
	return error.innerHTML = '';
}