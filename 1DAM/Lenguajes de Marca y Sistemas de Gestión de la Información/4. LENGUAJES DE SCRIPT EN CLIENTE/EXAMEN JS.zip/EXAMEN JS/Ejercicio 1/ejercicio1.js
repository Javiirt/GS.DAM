

function validar(){

	var nombre=document.getElementById("nombre").value
	
	if((nombre==null || nombre.length==0)||!isNaN(nombre)){

		alert("Introduce tu nombre y apellidos")
		return false


	}var telefono=document.getElementById("telefono").value
	
	if((telefono==null || telefono.length==0)||!(/^\d{9}/.test(telefono))){

		alert("Introduce tu numero correctamente")
		return false


	}
	var contraseña1=document.getElementById("contraseña1").value
	
	if(contraseña1==null || contraseña1.length<6){

		alert("Tiene que tener 6 caracteres")
		return false

}
	var contraseña2=document.getElementById("contraseña2").value
	
	if(contraseña2==null || contraseña2.length<6){

		alert("Tiene que tener 6 caracteres")
		return false
	
	}
	if(contraseña1!=contraseña2){
		alert("Las contraseñas no coinciden")
		return false

	}var correo=document.getElementById("correo").value
	
	if((correo==null || correo.length==0)||!(/\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.])\w+)*/.test(correo))){

		alert("Inserta un correo")
		return false
	
	}var profesion=document.getElementById("profesion").value

	if(profesion==null|| profesion==0){
		alert("Elige una opcion valida")
		return false

	}var genero=document.getElementsByName("genero")

	if(!genero.checked){

		alert("Elige una opcion valida")
		return false

		}

	
		
	return true

	}