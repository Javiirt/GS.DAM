
	
	$(document).ready(function(){
		
		$(".presente").click(function(){

			$(".nombre").css("background-color","green")
			$(".presente").hide()

	})

		$(".ausente").click(function(){
			$(".nombre").css("background-color","red")
			$(".ausente").hide()

	})

		$(".retraso").click(function(){
			$(".nombre").css("background-color","yellow")
			$(".retraso").hide()

	})

})

	