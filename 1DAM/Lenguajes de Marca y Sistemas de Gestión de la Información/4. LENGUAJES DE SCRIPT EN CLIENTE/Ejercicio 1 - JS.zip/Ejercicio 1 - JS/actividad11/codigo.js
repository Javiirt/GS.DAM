
document.write("Mensaje de texto")

