
document.write("<strong>Hola</strong")

