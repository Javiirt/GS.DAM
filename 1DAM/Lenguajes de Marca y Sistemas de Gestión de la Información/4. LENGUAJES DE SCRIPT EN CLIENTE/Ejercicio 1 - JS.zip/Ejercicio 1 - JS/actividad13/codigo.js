
var nombre=prompt("Introduce tu nombre")
alert("Bienvenido "+ nombre)
document.getElementById('bienvenido').innerHTML=nombre