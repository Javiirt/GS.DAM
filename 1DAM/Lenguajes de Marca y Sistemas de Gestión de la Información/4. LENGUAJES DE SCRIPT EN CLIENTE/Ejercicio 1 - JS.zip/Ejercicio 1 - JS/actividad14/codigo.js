
var mensaje


mensaje=confirm("¿Desea que gane la liga el Málaga?")

alert(mensaje)
document.write(mensaje)