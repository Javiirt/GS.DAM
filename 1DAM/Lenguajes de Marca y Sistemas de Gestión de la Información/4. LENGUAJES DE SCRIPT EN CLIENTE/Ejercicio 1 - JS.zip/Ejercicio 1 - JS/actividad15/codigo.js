
var mensaje


mensaje=prompt("Indique su codigo de usuario", "Anonymous")
document.write(mensaje)
alert(mensaje)
