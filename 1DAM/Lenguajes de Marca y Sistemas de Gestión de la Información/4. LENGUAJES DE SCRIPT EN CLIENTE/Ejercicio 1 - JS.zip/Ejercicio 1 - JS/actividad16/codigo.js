


var num1=prompt("Introduce el primer numero")
var num2=prompt("Introduce el segundo numero")

var resultado
resultado=parseInt(num1)+parseInt(num2)

document.write("El resultado de la suma de "+ num1+ " + "+ num2+" es igual a "+ resultado)

