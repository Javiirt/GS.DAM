
var numero

numero=prompt("Introduce un numero")
var par


if (numero%2==0)
	alert("Es par")

else
	alert("Es impar")
