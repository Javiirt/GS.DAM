window.alert("MENSAJE 1:Este es mi quinto ejercicio de Javascript")
window.alert("MENSAJE 2:Este es mi quinto ejercicio de Javascript")