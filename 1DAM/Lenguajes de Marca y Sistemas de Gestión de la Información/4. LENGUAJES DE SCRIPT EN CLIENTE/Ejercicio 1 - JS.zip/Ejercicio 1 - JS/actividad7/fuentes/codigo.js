
//Para crear una ventana de alerta utilizamos el metodo alert().

/*Entre los parentesis del metodo insertamos el texto, con comillas, que queremos que aparezca en la alerta*/


window.alert("MENSAJE 1:Este es mi quinto ejercicio de Javascript")
window.alert("MENSAJE 2:Este es mi quinto ejercicio de Javascript")