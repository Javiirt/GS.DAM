

/*Para crear una alerta utilizamos el metodo alert(). 
Entre los parentesis introducimos el texto entre comillas que queremos que aparezca. Las alertas saldran dependiendo del orden en el que coloquemos los alert.*/

alert("Hola mundo")
alert("Soy el primer script")
