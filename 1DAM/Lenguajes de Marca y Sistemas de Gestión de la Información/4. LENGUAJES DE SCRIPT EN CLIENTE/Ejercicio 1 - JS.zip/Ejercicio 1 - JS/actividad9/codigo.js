
var num1=7
var num2=4
var resultado

resultado=(num1+num2)

document.write(resultado+""/n)

document.write(resultado+"")

document.write(resultado+"")

document.write(resultado+"")