

function validar(){

			//Validar nombre
				var valN = document.getElementById('nombre1').value
				if((valN==null || valN.length==0)||!isNaN(valN)){
					console.log(valN)
					alert("ERROR al introducir el NOMBRE")
					return false
				}

			//Validar apellidos
				var valAp = document.getElementById('apellidos').value
				if((valAp==null || valAp.length==0)||!isNaN(valAp)){
					alert("ERROR al introducir el apellidos")
					return false
				}
				//Validar email
				var valE = document.getElementById('correo').value
				var erE = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
				if((valE==null||valE.length==0)||!(erE.test(valE))){				
					alert("Error correo")
					return false
				}
				//Validar dni
				var valDni = document.getElementById('dni').value
				var erDni = /^\d{8}[A-Z]$/
				var letras = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 
				'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'];
				if((valDni==null|| valDni.length == 0)||(!(erDni.test(valDni)))){				
					alert("DNI ERRONEO")
					return false
				}
				if(valDni.charAt(8) != letras[(valDni.substring(0,8))%23] ){
					alert("DNI ERRONEO")
					return false
				}
					//Validar seleccion
				var valS = document.getElementById('hora').selectedIndex
				if(valS == "" || valS == 0){
					alert("Error seleccion de hora")
					return false
				}
					//Validar radio
				var opciones = document.getElementsByName("formulario1")
				var seleccionado = false
				for(var i = 0; i < opciones.length; i++){
					if(opciones[i].checked){
						seleccionado = true
						break;
					}
				}
				if(!seleccionado){
						alert("Debe seleccionar un curso");
						return false
					}
				//Validar checkbox
				var recorrer = formulario.elements.length;
				for(var i = 0; i < recorrer; i++){
					var elementosFor = formulario.elements[i]
					if (elementosFor.type == "checkbox") {
						if (!elementosFor.checked) {
							alert("Acepta los términos y condiciones de uso para continuar");
							return false
						}
					}
				}
	
				return true
		}

function validar2(){

		//Validar nombre
				var valCN = document.getElementById('nombre').value
				if((valCN==null || valCN.length==0)||!isNaN(valCN)){
					alert("ERROR al introducir el NOMBRE")
					return false
				}
				//Validar email
				var valCE = document.getElementById('correo').value
				var erE = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
				if((valCE==null||valCE.length==0)||!(erE.test(valCE))){				
					alert("Error correo")
					return false
				}

						//validar consulta
				var valCC = document.getElementById('consulta').value
				if((valCC==null || valCC.length==0)||!isNaN(valCC)){
					alert("Rellena la consulta")
					return false
				}

		
				return true
		}
		
		/*Descativar copiar pegar y cortar*/
	
	$(document).ready(function () {

    $('body').bind('cut copy paste', function (e) {
        e.preventDefault();
    });

});
	/*Desactivar click derecho*/
	$(document).ready(function () {
    $("body").on("contextmenu",function(e){
        return false;
    });
});

	/*Galeria*/

	$(document).ready(function(){
          
          $(".gal").click(function(){
            var imagensrc= $(this).attr('src');
             var codigo='<div id="encima"><img id="foto11" src="'+imagensrc+'"><div id="botonx">X</div></div>'
            $("#mainp").append(codigo);
            $("#botonx").click(function(){
              $("#encima").remove()
           

            })     

        })


      })

	
	 


