/*QUIZ DE PREGUNTAS*/
    

    $(document).ready(function(){
        /*Comenzamos con la pregunta 2 y 3 ocultas. Solo dejamos a la vista la pregunta 1. Cada boton será una opción. Si pulsamos los botones incorrectos,
         el video de presentacion se sustituye por el de error.*/
        
        $("#pregunta2").hide()
        $("#pregunta3").hide()
       $(".boton1919").click(function(){
        $("#grumeteinicio").replaceWith('<video id="grumeteinicio" autoplay><source id="grumeteinicio" src="video/grumetefallo.mp4"></video>')


       })
       $(".boton1522").click(function(){
        $("#grumeteinicio").replaceWith('<video id="grumeteinicio" autoplay><source id="grumeteinicio" src="video/grumetefallo.mp4"></video>')

        /*Cuando pulsamos sobre la opcion correcta, reemplazamos por el video grumeteok.mp4, ocultamos la pregunta 1 y mostramos la pregunta 2*/

       })
       $(".boton1519").click(function(){
        $("#grumeteinicio").replaceWith('<video id="grumeteinicio" autoplay><source id="grumeteinicio" src="video/grumeteok.mp4"></video>')
        $("#pregunta1").hide()
        $("#pregunta2").show()
       })

       $(".botondescubrir").click(function(){
        $("#grumeteinicio").replaceWith('<video id="grumeteinicio" autoplay><source id="grumeteinicio" src="video/grumetefallo.mp4"></video>')

    })
       $(".botonruta").click(function(){
        $("#grumeteinicio").replaceWith('<video id="grumeteinicio" autoplay><source id="grumeteinicio" src="video/grumeteok.mp4"></video>')
        $("#pregunta2").hide()
        $("#pregunta3").show()
    })
       $(".botonnavegar").click(function(){
        $("#grumeteinicio").replaceWith('<video id="grumeteinicio" autoplay><source id="grumeteinicio" src="video/grumetefallo.mp4"></video>')

    })
       /*En la ultima correcta, intercambiamos por un videofinal.mp4 y reemplazamos por un <p>*/
       
        $(".boton5").click(function(){
        $("#grumeteinicio").replaceWith('<video id="grumeteinicio" autoplay><source id="grumeteinicio" src="video/grumetefinal.mp4"></video>')
        $("#pregunta3").replaceWith("<div id='pregunta3'><p>GRACIAS POR PARTICIPAR</p></div")
    })
        $(".boton3").click(function(){
        $("#grumeteinicio").replaceWith('<video id="grumeteinicio" autoplay><source id="grumeteinicio" src="video/grumetefallo.mp4"></video>')

    })
        $(".boton6").click(function(){
        $("#grumeteinicio").replaceWith('<video id="grumeteinicio" autoplay><source id="grumeteinicio" src="video/grumetefallo.mp4"></video>')

    })
})
    

















        