
import java.util.Scanner;

public class Ejercicio2 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca una cadena");
        String cadena = sc.nextLine();
        System.out.println("Introduzca el máximo número de caracteres por línea");
        int numero = sc.nextInt();
        String linea = "";
        String palabra = "";
        for(int i=0; i<cadena.length();i++){            
            palabra+=cadena.charAt(i);
            if(cadena.charAt(i)==' '){
                if(linea.length()+palabra.length()>numero){
                    System.out.println(linea);
                    linea = "";
                }
                
                linea+=palabra;
                palabra="";
            } 
            if(i==cadena.length()-1){
                linea+=palabra;
                System.out.println(linea);
            }           
        }
    }       
}
