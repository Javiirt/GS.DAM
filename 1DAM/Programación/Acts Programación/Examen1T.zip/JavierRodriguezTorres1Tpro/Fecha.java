
public class Fecha {
    
    private int dia;
    private int mes;
    private int año;
    
    Fecha(){
        dia = 1;
        mes = 1;
        año = 2019;
    }
    
    Fecha(int ndia, int nmes, int naño){
        /*No se especifica en el enunciado una verificación,
        en caso de que se pidiese solo habría que añadir la 
        misma condición creada en el método setFecha(int, int, int)*/
        dia = ndia;
        mes = nmes;
        año = naño; 
    }
    
    void setFecha(int ndia, int nmes, int naño){
        if(ndia>=1 && ndia<=30 && nmes>=1 && nmes<=30){
            dia = ndia;
            mes = nmes;
            año = naño;
        }else{
            System.out.println("Error al introducir los valores de la fecha");
        }        
    }
    
    void setFecha(String fecha){
        int barra1 = fecha.indexOf('/');
        int barra2 = fecha.lastIndexOf('/');
        int ndia = Integer.parseInt(fecha.substring(0, barra1));
        int nmes = Integer.parseInt(fecha.substring(barra1+1, barra2));
        int naño = Integer.parseInt(fecha.substring(barra2+1));
        if(ndia>=1 && ndia<=30 && nmes>=1 && nmes<=30){
            dia = ndia;
            mes = nmes;
            año = naño;
        }else{
            System.out.println("Error al introducir la fecha");
        }  
    }
    
    String getFecha(){
        String fecha=dia+"/"+mes+"/"+año;
        return fecha;
    }
    
    String periodo(Fecha fechaNueva){
        int diasFecha1 = dia+mes*30+año*365;
        int diasFecha2 = fechaNueva.dia+fechaNueva.mes*30+fechaNueva.año*365;
        int total = diasFecha1-diasFecha2;
        if (total<0){
            total*=-1;
        }
        int difAño = total/365;
        int difMes = (total%365)/30;
        int difDia = (total%365)%30;        
        String diferencia = difDia+" dias/"+difMes+" meses/"+difAño+" años";
        return diferencia;
    }
    
    String menor(Fecha fechaNueva){
        String menor;
        if(año<fechaNueva.año){
            menor = getFecha();
        }else if(año>fechaNueva.año){
            menor = fechaNueva.getFecha();
        }else{
            if(mes<fechaNueva.mes){
                menor = getFecha();
            }else if(mes>fechaNueva.mes){
                menor = fechaNueva.getFecha();
            }else{
                if(dia<fechaNueva.dia){
                    menor = getFecha();
                }else if(dia>fechaNueva.dia){
                    menor = fechaNueva.getFecha();
                }else{
                    menor = getFecha();
                }
            }
        }
        return menor;
    }
    
    public static void main(String[] args) {
        Fecha fecha1 = new Fecha(10,10,2021);
        Fecha fecha2 = new Fecha();
        fecha2.setFecha("10/12/2021");
        System.out.println("La fecha menor es: "+fecha1.menor(fecha2));
        System.out.println("La diferencia entre las dos fechas es de : "+fecha1.periodo(fecha2));
    }
}
