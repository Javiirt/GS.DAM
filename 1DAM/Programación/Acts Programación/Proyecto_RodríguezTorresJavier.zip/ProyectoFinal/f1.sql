DROP TABLE escuderia;
DROP TABLE piloto;
DROP TABLE circuito;


CREATE TABLE escuderia( 	
   	nomesc VARCHAR2(30),
	pais VARCHAR2(30),  
	color VARCHAR2(15),
   	fundacion NUMBER,
	PRIMARY KEY(nomesc) 
);

CREATE TABLE piloto( 
	dorsal NUMBER, 
    	nompil VARCHAR2(30),
	nomesc VARCHAR2(30), 
    	nacionalidad VARCHAR2(30), 
    	fechanac VARCHAR2(10),     	
	PRIMARY KEY (dorsal)
);

CREATE TABLE circuito(
	nomcir VARCHAR2(30),
	pais VARCHAR2(30),
	ganador NUMBER,
	PRIMARY KEY (nomcir)
);

INSERT INTO escuderia VALUES('Ferrai','Italia','Rojo',1939);
INSERT INTO escuderia VALUES('Red Bull','Austria','Marino',2004);
INSERT INTO escuderia VALUES('Mercedes','Alemania','Gris',1954);
INSERT INTO escuderia VALUES('McLaren','Inglaterra','Naranja', 1963);
INSERT INTO escuderia VALUES('Alpine','Francia','Azul',2020);
INSERT INTO escuderia VALUES('Aston Martin','Inglaterra','Verde',1959);



INSERT INTO piloto VALUES(16, 'Leclerc', 'Ferrai', 'Monaco', '16-10-1997');
INSERT INTO piloto VALUES(1, 'Verstappen', 'Red Bull', 'Holanda', '30-09-1997');
INSERT INTO piloto VALUES(44, 'Hamilton', 'Ferrai', 'Inglaterra', '07-01-1985');
INSERT INTO piloto VALUES(14, 'Alonso', 'Alpine', 'España', '29-07-1981');
INSERT INTO piloto VALUES(4, 'Norris', 'McLaren', 'Inglaterra', '13-11-1999');
INSERT INTO piloto VALUES(5, 'Vettel', 'Aston Martin', 'Alemania', '03-04-1987');



INSERT INTO circuito VALUES('Monza', 'Italia', 1);
INSERT INTO circuito VALUES('Spa-Francorchamps', 'Belgica', 4);
INSERT INTO circuito VALUES('Zandvoort', 'Holanda', 1);
INSERT INTO circuito VALUES('Silverstone', 'Inglaterra', 44);
INSERT INTO circuito VALUES('Monaco', 'Monaco', 16);
INSERT INTO circuito VALUES('Cataluña', 'España', 14);





















