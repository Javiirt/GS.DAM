/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package f1;


import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
public class accion extends JFrame implements ActionListener{
    private JLabel texto; 
    private JButton ver;
    private JButton alta;
    private JButton baja;
    private JButton editar;
    private JButton salir;
    
    public accion() {
      super(); 
      configurarVentana(); 
      inicializarComponentes();
      setVisible(true);
    }

    private void configurarVentana() {
       this.setTitle("ELEGIR ACCIÓN");
       this.setSize(500, 500); // colocamos tamanio a la ventana (ancho, alto)
       this.setLocationRelativeTo(null); // centramos la ventana en la pantalla
       this.setLayout(null);
       this.setResizable(false);
       this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void inicializarComponentes() {
        
        texto = new JLabel();
        ver = new javax.swing.JButton();
        alta = new javax.swing.JButton();
        baja = new javax.swing.JButton();
        editar = new javax.swing.JButton();
        salir = new javax.swing.JButton();
        
        
        texto.setText("Elija qué desea hacer");
        texto.setBounds(130, 30, 400, 50);   //(x, y, ancho, alto)
        texto.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));

        ver.setText("Ver tabla");
        ver.setBounds(80, 100, 320, 50);
        ver.addActionListener(this); 
        ver.setActionCommand("ver");
        ver.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));
        
        alta.setText("Añadir elemento");
        alta.setBounds(80, 160, 320, 50);
        alta.addActionListener(this); 
        alta.setActionCommand("alta");
        alta.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));
        
        baja.setText("Eliminar elemento");
        baja.setBounds(80, 220, 320, 50);
        baja.addActionListener(this); 
        baja.setActionCommand("eliminar");
        baja.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));

        editar.setText("Editar tabla");
        editar.setBounds(80, 280, 320, 50);
        editar.addActionListener(this); 
        editar.setActionCommand("editar");
        editar.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));
        
        
        salir.setText("Salir");
        salir.setBounds(300, 360, 100, 50);
        salir.addActionListener(this); 
        salir.setActionCommand("salir");
        salir.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));
        
        this.add(texto);
        this.add(ver);
        this.add(alta);
        this.add(baja);
        this.add(editar);
        this.add(salir);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String accion = e.getActionCommand();
        if("salir".equals(accion)){
            dispose();
        }else{
            campos ventanaCampos = new campos(accion); 
        }
    }    
}


