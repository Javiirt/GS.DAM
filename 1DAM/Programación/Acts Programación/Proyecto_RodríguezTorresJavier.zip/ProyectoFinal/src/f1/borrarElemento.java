/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package f1;

import static f1.dao.borrarCircuito;
import static f1.dao.borrarEscuderia;
import static f1.dao.borrarPiloto;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class borrarElemento extends JFrame implements ActionListener{
    private JLabel texto;     
    private JLabel label;
    private JTextField caja;
    private JTextField resultado;
    private JButton salir;
    private JButton borrar;
    public String tabla;
    
    public borrarElemento(String tabla) {
      super(); 
      this.tabla = tabla;
      configurarVentana(); 
      inicializarComponentes();
      setVisible(true);
      
    }

    private void configurarVentana() {
       this.setTitle("ELIMINAR ELEMENTO");
       this.setSize(500, 500); // colocamos tamanio a la ventana (ancho, alto)
       this.setLocationRelativeTo(null); // centramos la ventana en la pantalla
       this.setLayout(null);
       this.setResizable(false);
       this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void inicializarComponentes() {
        
        texto = new JLabel();        
        label = new JLabel();
        caja = new JTextField();
        resultado = new JTextField();
        borrar = new JButton();
        salir = new JButton();
        
        texto.setText("ELIMINAR ELEMENTO DE "+tabla.toUpperCase());
        texto.setBounds(60, 30, 400, 50);   //(x, y, ancho, alto)
        texto.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));
        
        switch(tabla){
            case "escuderia":
                label.setText("Nombre del equipo a borrar:");
                break;
            case "piloto":
                label.setText("Dorsal del piloto a borrar:");
                break;
            case "circuito":
                label.setText("Nombre del circuito a borrar:");
                break;
            default: 
                label.setText("Error");
                break;
        }
        
        label.setBounds(60, 100, 380, 50);   //(x, y, ancho, alto)
        label.setFont(new Font(Font.DIALOG, Font.PLAIN, 20));
        
        caja.setBounds(60, 160, 380, 50);
        caja.setFont(new Font(Font.DIALOG, Font.PLAIN, 14));
                
        resultado.setBounds(150, 250, 190, 40);
        resultado.setFont(new Font(Font.DIALOG, Font.PLAIN, 14));
        resultado.setEditable(false);
        
        borrar.setText("Borrar");
        borrar.setBounds(60, 360, 120, 50);
        borrar.addActionListener(this); 
        borrar.setActionCommand("borrar");
        borrar.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));
        
        salir.setText("Volver");
        salir.setBounds(320, 360, 120, 50);
        salir.addActionListener(this); 
        salir.setActionCommand("volver");
        salir.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));
        
        
        this.add(texto);
        this.add(label);
        this.add(caja);
        this.add(resultado);
        this.add(borrar);
        this.add(salir);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String pulsar = e.getActionCommand();
        String respuesta = caja.getText();
        
        if("volver".equals(pulsar)){
            dispose();
        }else if("borrar".equals(pulsar)){
            switch(tabla){
                case "escuderia":
                    resultado.setText(borrarEscuderia(respuesta));
                    break;
                case "piloto":
                    resultado.setText(borrarPiloto(Integer.parseInt(respuesta)));
                    break;
                case "circuito":
                    resultado.setText(borrarCircuito(respuesta));
                    break;
                default: 
                    resultado.setText("Error al borrar");
                    break;
            }
        }
    }
}
