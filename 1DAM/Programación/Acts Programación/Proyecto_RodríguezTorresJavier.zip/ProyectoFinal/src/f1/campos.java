
package f1;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class campos extends JFrame implements ActionListener{
    private JLabel texto; 
    private JButton escudería; 
    private JButton piloto; 
    private JButton circuito; 
    private JButton salir;
    public String accion;
    
    public campos(String accion) {
      super(); 
      this.accion = accion;
      configurarVentana(); 
      inicializarComponentes();
      setVisible(true);
      
    }

    private void configurarVentana() {
       this.setTitle("ELEGIR CAMPO");
       this.setSize(500, 500); // colocamos tamanio a la ventana (ancho, alto)
       this.setLocationRelativeTo(null); // centramos la ventana en la pantalla
       this.setLayout(null);
       this.setResizable(false);
       this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void inicializarComponentes() {
        
        texto = new JLabel();
        escudería = new JButton();
        piloto = new JButton();
        circuito = new JButton();
        salir = new JButton();
        
        texto.setText("Elija con qué tabla desea interactuar");
        texto.setBounds(60, 30, 400, 50);   //(x, y, ancho, alto)
        texto.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));

        escudería.setText("Escudería");
        escudería.setBounds(70, 120, 350, 50);
        escudería.addActionListener(this); 
        escudería.setActionCommand("escuderia");
        escudería.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));
        
        piloto.setText("Piloto");
        piloto.setBounds(70, 200, 350, 50);
        piloto.addActionListener(this); 
        piloto.setActionCommand("piloto");
        piloto.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));
        
        circuito.setText("Circuito");
        circuito.setBounds(70, 280, 350, 50);
        circuito.addActionListener(this); 
        circuito.setActionCommand("circuito");
        circuito.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));

        salir.setText("Volver");
        salir.setBounds(300, 360, 120, 50);
        salir.addActionListener(this); 
        salir.setActionCommand("volver");
        salir.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));
        
        
        this.add(texto);
        this.add(escudería);
        this.add(piloto);
        this.add(circuito);
        this.add(salir);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String tabla = e.getActionCommand();
        if("volver".equals(tabla)){
            dispose();
        }else{
            switch(accion){
                case "ver":
                    verTabla vista = new verTabla(tabla);
                    break;
                    
                case "alta":                    
                    switch(tabla){
                        case "escuderia":
                            insertarEscuderia insesc = new  insertarEscuderia();
                            break;
                        case "piloto":
                            insertarPiloto inspil = new  insertarPiloto();
                            break;
                        case "circuito":
                            insertarCircuito inscir = new  insertarCircuito();
                            break;                        
                    }
                    break;
                    
                case "eliminar":
                    borrarElemento borrar = new borrarElemento(tabla);
                    break;
                    
                case "editar" :
                    switch(tabla){
                        case "escuderia":
                            modificarEscuderia modesc = new  modificarEscuderia();
                            break;
                        case "piloto":
                            modificarPiloto modpil = new  modificarPiloto();
                            break;
                        case "circuito":
                            modificarCircuito modcir = new  modificarCircuito();
                            break;                        
                    }
                    break;
                    
            }
        }
    }
}

