package f1;

/**
 *
 * @author javir
 */
import java.sql.*;

public class dao {
    
    static String driver="com.mysql.jdbc.Driver";

    
    /*Métodos para las 3 tablas que devuelve los datos almacenados en un String*/
    
    //Método que devuelve los datos de la tabla escuderia
    public static String mostrarEscuderia(){
        
        String cadena = "";
        String query="SELECT * FROM escuderia";

        try{	
                        
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            Connection connection = DriverManager.getConnection
            /* Clase */ ("jdbc:oracle:thin:@delfos:1521:XE", "javierroto", "uno");
            
            Statement statement=connection.createStatement();
            ResultSet result=statement.executeQuery(query);
            
            
            while(result.next()){
                cadena+= "--------------------------------------------------\n";
                cadena+= "\nESCUDERÍA: "+result.getString(1);
                cadena+= "\nPAÍS: "+result.getString(2);
                cadena+= "\nCOLOR DEL COCHE: "+result.getString(3);
                cadena+= "\nAÑO DE FUNDACIÓN: "+result.getInt(4)+"\n\n";
            }
		 
            result.close();
            statement.close();
            connection.close();
            
        }catch(UnsupportedClassVersionError cnfe){
            cadena = "Error con la version";
        }catch(NumberFormatException cnfe){  
            cadena = "Parámetros introducidos no válidos";
        }catch(ClassNotFoundException cnfe){  
            cadena = "Error al conectar con el driver";
        }catch (SQLException sqle){
            cadena = "Error de SQL";
        }

        return cadena;
    }
    
    //Método que devuelve los datos de la tabla piloto
    public static String mostrarPilotos(){
        
        String cadena = "";
        String query="SELECT * FROM piloto";

        try{	
                        
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            Connection connection = DriverManager.getConnection
            /* Casa *///("jdbc:oracle:thin:@localhost:1521:XE", "System", "system");
            /* Clase */ ("jdbc:oracle:thin:@delfos:1521:XE", "javierroto", "uno");
            
            Statement statement=connection.createStatement();
            ResultSet result=statement.executeQuery(query);
            
            
            while(result.next()){
                cadena+= "--------------------------------------------------\n";
                cadena+= "\nPILOTO: "+result.getString(2);
                cadena+= "\nDORSAL: "+result.getInt(1);
                cadena+= "\nESCUDERÍA: "+result.getString(3);
                cadena+= "\nNACIONALIDAD: "+result.getString(4);
                cadena+= "\nFECHA DE NACIMIENTO: "+result.getString(5)+"\n\n";
            }
		 
            result.close();
            statement.close();
            connection.close();
            
        }catch(UnsupportedClassVersionError cnfe){
            cadena = "Error con la version";
        }catch(NumberFormatException cnfe){  
            cadena = "Parámetros introducidos no válidos";
        }catch(ClassNotFoundException cnfe){  
            cadena = "Error al conectar con el driver";
        }catch (SQLException sqle){
            cadena = "Error de SQL";
        }

        return cadena;
    }
    
    //Método que devuelve los datos de la tabla circuito
    public static String mostrarCircuitos(){
        
        String cadena = "";
        String query="SELECT * FROM circuito";

        try{	
                        
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            Connection connection = DriverManager.getConnection
            /* Clase */ ("jdbc:oracle:thin:@delfos:1521:XE", "javierroto", "uno");
            
            Statement statement=connection.createStatement();
            ResultSet result=statement.executeQuery(query);
            
            
            while(result.next()){
                cadena+= "--------------------------------------------------\n";
                cadena+= "\nCIRCUITO: "+result.getString(1);
                cadena+= "\nPAÍS: "+result.getString(2);
                cadena+= "\nDORSAL GANADOR: "+result.getInt(3)+"\n\n";
            }
		 
            result.close();
            statement.close();
            connection.close();
					
        }catch(UnsupportedClassVersionError cnfe){
            cadena = "Error con la version";
        }catch(NumberFormatException cnfe){  
            cadena = "Parámetros introducidos no válidos";
        }catch(ClassNotFoundException cnfe){  
            cadena = "Error al conectar con el driver";
        }catch (SQLException sqle){
            cadena = "Error de SQL";
        }

        return cadena;
    }
    
    
    /*Métodos para las 3 tablas que inserta un elemento en la tabla 
    y devuelve la accion que se ha realizado o si hay algún error*/
    
    //Método que inserta un elemento en la tabla escuderia
    public static String insertarEscuderia(String nombre, String pais, String color, int anio){
        String cadena = "";
        String insert="INSERT INTO escuderia VALUES('"+nombre+"', '"+pais+"', '"+color+"', "+anio+")";

        try{	
                        
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            Connection connection = DriverManager.getConnection
            /* Clase */ ("jdbc:oracle:thin:@delfos:1521:XE", "javierroto", "uno");
            
            Statement statement=connection.createStatement();
	    
            try{
                statement.executeUpdate(insert);
                cadena+="Escudería añadida";
            }catch(SQLException sqle){
                cadena+="La escudería introducida ya existe";
                sqle.printStackTrace();
            }
            
            statement.close();
            connection.close();
					
        }catch(UnsupportedClassVersionError cnfe){
            cadena = "Error con la version";
        }catch(NumberFormatException cnfe){  
            cadena = "Parámetros introducidos no válidos";
        }catch(ClassNotFoundException cnfe){  
            cadena = "Error al conectar con el driver";
        }catch (SQLException sqle){
            cadena = "Error de SQL";
        }
        
        return cadena;
    }
    
    //Método que inserta un elemento en la tabla piloto
    public static String insertarPiloto(int dorsal, String nombre, String escuderia, String pais, String fecha){
        String cadena = "";
        String insert="INSERT INTO piloto VALUES('"+dorsal+"', '"+nombre+"', '"+escuderia+"', '"+pais+"', '"+fecha+"');";

        try{	
                        
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            Connection connection = DriverManager.getConnection
            /* Clase */ ("jdbc:oracle:thin:@delfos:1521:XE", "javierroto", "uno");
            
            Statement statement=connection.createStatement();
	    
            try{
                statement.executeUpdate(insert);
                cadena+="Piloto añadido";
            }catch(SQLException sqle){
                cadena+="El piloto introducido ya existe";
                sqle.printStackTrace();
            }
            
            statement.close();
            connection.close();
					
        }catch(UnsupportedClassVersionError cnfe){
            cadena = "Error con la version";
        }catch(NumberFormatException cnfe){  
            cadena = "Parámetros introducidos no válidos";
        }catch(ClassNotFoundException cnfe){  
            cadena = "Error al conectar con el driver";
        }catch (SQLException sqle){
            cadena = "Error de SQL";
        }
        
        return cadena;
    }
    
    //Método que inserta un elemento en la tabla circuito
    public static String insertarCircuito(String nombre, String pais, int dorsal){
        String cadena = "";
        String insert="INSERT INTO circuito VALUES('"+nombre+"', '"+pais+"', "+dorsal+")";

        try{	
                        
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            Connection connection = DriverManager.getConnection
            /* Clase */ ("jdbc:oracle:thin:@delfos:1521:XE", "javierroto", "uno");
            
            Statement statement=connection.createStatement();
	    
            try{
                statement.executeUpdate(insert);
                cadena+="Circuito añadido";
            }catch(SQLException sqle){
                cadena+="El circuito introducido ya existe";
                sqle.printStackTrace();
            }
            
            statement.close();
            connection.close();
					
        }catch(UnsupportedClassVersionError cnfe){
            cadena = "Error con la version";
        }catch(NumberFormatException cnfe){  
            cadena = "Parámetros introducidos no válidos";
        }catch(ClassNotFoundException cnfe){  
            cadena = "Error al conectar con el driver";
        }catch (SQLException sqle){
            cadena = "Error de SQL";
        }
        
        return cadena;
    }
    
    
    /*Métodos para las 3 tablas que elimina un elemento en la tabla 
    y devuelve la accion que se ha realizado o si hay algún error*/
    
    //Método que elimina un elemento en la tabla escuderia
    public static String borrarEscuderia(String nombre){
        String cadena="";
        String eliminar="DELETE FROM escuderia WHERE nomesc = '"+nombre+"'";
        String existe="SELECT * FROM escuderia where nomesc = '"+nombre+"'";
        try{	

            Class.forName("oracle.jdbc.driver.OracleDriver");

            Connection connection = DriverManager.getConnection
            /* Clase */ ("jdbc:oracle:thin:@delfos:1521:XE", "javierroto", "uno");
            
            Statement statement=connection.createStatement();
            ResultSet result=statement.executeQuery(existe);
            
            if(result.next()){
                try{
                    statement.executeUpdate(eliminar);
                    cadena ="Escudería eliminada";
                }catch(SQLException sqle){
                    cadena ="Error al eliminar escudería";
                }
            }else{
                cadena = "La escudería no existe";
            }
            
            result.close();
            statement.close();
            connection.close();


        }catch(UnsupportedClassVersionError cnfe){
            cadena = "Error con la version";
        }catch(NumberFormatException cnfe){  
            cadena = "Parámetros introducidos no válidos";
        }catch(ClassNotFoundException cnfe){  
            cadena = "Error al conectar con el driver";
        }catch (SQLException sqle){
            cadena = "Error de SQL";
        }
        
        return cadena;
    }
    
    //Método que elimina un elemento en la tabla piloto
    public static String borrarPiloto(int dorsal){
        String cadena="";
        String eliminar="DELETE FROM piloto WHERE dorsal = "+dorsal;
        String existe="SELECT * FROM piloto where dorsal = '"+dorsal+"'";
        
        try{	

            Class.forName("oracle.jdbc.driver.OracleDriver");

            Connection connection = DriverManager.getConnection
            /* Clase */ ("jdbc:oracle:thin:@delfos:1521:XE", "javierroto", "uno");
            
            Statement statement=connection.createStatement();
            ResultSet result=statement.executeQuery(existe);
            
            if(result.next()){
                try{
                    statement.executeUpdate(eliminar);
                    cadena="Piloto eliminado";
                }catch(SQLException sqle){
                    cadena="Error al eliminar piloto";
                }
            }else{
                cadena = "El piloto no existe";
            }
            
            result.close();
            statement.close();
            connection.close();


        }catch(UnsupportedClassVersionError cnfe){
            cadena = "Error con la version";
        }catch(NumberFormatException cnfe){  
            cadena = "Parámetros introducidos no válidos";
        }catch(ClassNotFoundException cnfe){  
            cadena = "Error al conectar con el driver";
        }catch (SQLException sqle){
            cadena = "Error de SQL";
        }
        
        return cadena;
    }
    
    //Método que elimina un elemento en la tabla circuito
    public static String borrarCircuito(String nombre){
        String cadena="";
        String eliminar="DELETE FROM circuito WHERE nomcir = '"+nombre+"'";
        String existe="SELECT * FROM circuito WHERE nomcir = '"+nombre+"'";
        try{	

            Class.forName("oracle.jdbc.driver.OracleDriver");

            Connection connection = DriverManager.getConnection
            /* Clase */ ("jdbc:oracle:thin:@delfos:1521:XE", "javierroto", "uno");
            
            Statement statement=connection.createStatement();
            ResultSet result=statement.executeQuery(existe);
            
            if(result.next()){
                try{
                    statement.executeUpdate(eliminar);
                cadena+="Circuito eliminado";
                }catch(SQLException sqle){
                    cadena+="Error al eliminar circuito";
                }
            }else{
                cadena = "El circuito no existe";
            }
            
            result.close();
            statement.close();
            connection.close();


        }catch(UnsupportedClassVersionError cnfe){
            cadena = "Error con la version";
        }catch(NumberFormatException cnfe){  
            cadena = "Parámetros introducidos no válidos";
        }catch(ClassNotFoundException cnfe){  
            cadena = "Error al conectar con el driver";
        }catch (SQLException sqle){
            cadena = "Error de SQL";
        }
        
        return cadena;
    }
    
    
    /*Métodos para las 3 tablas que actualiza un elemento en la tabla 
    y devuelve la accion que se ha realizado o si hay algún error*/
    
    //Método que actualiza un elemento en la tabla escuderia
    public static String modificarEscuderia(String nombre, String pais, String color, int anio){
        String cadena = "";
        String modificar="UPDATE escuderia SET pais = '"+pais+"', color  = '"+color+"',fundacion  = "+anio+" WHERE nomesc = '"+nombre+"'";
        
        try{	
                        
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            Connection connection = DriverManager.getConnection
            /* Clase */ ("jdbc:oracle:thin:@delfos:1521:XE", "javierroto", "uno");
            
            Statement statement=connection.createStatement();
	    
            try{
                statement.executeUpdate(modificar);
                cadena+="Escudería actualizada";
            }catch(SQLException sqle){
                cadena+="La escudería no existe";
                sqle.printStackTrace();
            }
            
            statement.close();
            connection.close();
					
        }catch(UnsupportedClassVersionError cnfe){
            cadena = "Error con la version";
        }catch(NumberFormatException cnfe){  
            cadena = "Parámetros introducidos no válidos";
        }catch(ClassNotFoundException cnfe){  
            cadena = "Error al conectar con el driver";
        }catch (SQLException sqle){
            cadena = "Error de SQL";
        }

        return cadena;
        
    }
    
    //Método que actualiza un elemento en la tabla piloto
    public static String modificarPiloto(int dorsal, String nombre, String escuderia, String pais, String fecha){
        String cadena = "";
        String modificar="UPDATE piloto SET nompil = '"+nombre+"', nomesc  = '"+escuderia+"', nacionalidad  = '"+pais+"',fechanac  = '"+fecha+"' WHERE dorsal = "+dorsal;
        
        try{	
                        
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            Connection connection = DriverManager.getConnection
            /* Clase */ ("jdbc:oracle:thin:@delfos:1521:XE", "javierroto", "uno");
            
            Statement statement=connection.createStatement();
	    
            try{
                statement.executeUpdate(modificar);
                cadena+="Piloto actualizado";
            }catch(SQLException sqle){
                cadena+="El piloto no existe";
                sqle.printStackTrace();
            }
            
            statement.close();
            connection.close();
					
        }catch(UnsupportedClassVersionError cnfe){
            cadena = "Error con la version";
        }catch(NumberFormatException cnfe){  
            cadena = "Parámetros introducidos no válidos";
        }catch(ClassNotFoundException cnfe){  
            cadena = "Error al conectar con el driver";
        }catch (SQLException sqle){
            cadena = "Error de SQL";
        }
        
        return cadena;
    }
    
    //Método que actualiza un elemento en la tabla circuito
    public static String modificarCircuito(String nombre, String pais, int dorsal){
        String cadena = "";
        String modificar="UPDATE circuito SET pais = '"+pais+"', ganador  = "+dorsal+" WHERE nomcir = '"+nombre+"'";
        
        try{	
                        
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            Connection connection = DriverManager.getConnection
            /* Clase */ ("jdbc:oracle:thin:@delfos:1521:XE", "javierroto", "uno");
            
            Statement statement=connection.createStatement();
	    
            try{
                statement.executeUpdate(modificar);
                cadena+="Circuito actualizado";
            }catch(SQLException sqle){
                cadena+="El circuito no existe";
                sqle.printStackTrace();
            }
            
            statement.close();
            connection.close();
					
        }catch(UnsupportedClassVersionError cnfe){
            cadena = "Error con la version";
        }catch(NumberFormatException cnfe){  
            cadena = "Parámetros introducidos no válidos";
        }catch(ClassNotFoundException cnfe){  
            cadena = "Error al conectar con el driver";
        }catch (SQLException sqle){
            cadena = "Error de SQL";
        }
        
        return cadena;
    }
}