
package f1;

public class main {   	
    public static void main(String[] args){
       accion principal = new accion();
    }        
}
