
package f1;

import static f1.dao.mostrarCircuitos;
import static f1.dao.mostrarEscuderia;
import static f1.dao.mostrarPilotos;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author javir
 */
public class verTabla extends JFrame implements ActionListener{
    private JLabel texto; 
    private JButton salir;
    private TextArea panel;
    public String tabla;
    
    public verTabla(String tabla) {
      super(); 
      this.tabla = tabla;
      configurarVentana(); 
      inicializarComponentes();
      setVisible(true);
      
    }

    private void configurarVentana() {
       this.setTitle("VER TABLA");
       this.setSize(500, 500); // colocamos tamanio a la ventana (ancho, alto)
       this.setLocationRelativeTo(null); // centramos la ventana en la pantalla
       this.setLayout(null);
       this.setResizable(false);
       this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void inicializarComponentes() {
        
        texto = new JLabel();
        salir = new JButton();
        panel = new TextArea();
        
        texto.setText("TABLA "+tabla.toUpperCase());
        texto.setBounds(60, 30, 400, 50);   //(x, y, ancho, alto)
        texto.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));
        
        String mostrar = "";
        switch(tabla){
            case "escuderia":
                mostrar = mostrarEscuderia();
                break;
            case "piloto":
                mostrar =mostrarPilotos();
                break;
            case "circuito":
                mostrar = mostrarCircuitos();
                break;
        }
        
        panel.setText(mostrar);
        panel.setBounds(60, 100, 380, 250);   //(x, y, ancho, alto)
        panel.setFont(new Font(Font.DIALOG, Font.PLAIN, 20));
        panel.setEditable(false);
        
        salir.setText("Volver");
        salir.setBounds(320, 360, 120, 50);
        salir.addActionListener(this); 
        salir.setActionCommand("volver");
        salir.setFont(new Font(Font.DIALOG, Font.PLAIN, 24));
        
        
        this.add(texto);
        this.add(panel);
        this.add(salir);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String pulsar = e.getActionCommand();
        if("volver".equals(pulsar)){
            dispose();
        }
    }  
}

