import java.util.Scanner;
import java.lang.Math;
public class Ejercicio1{

    public static void main(String[] args) {

      	Scanner sc = new Scanner(System.in);
	    System.out.println("Ejercicio 1");
	    double base, altura, diagonal;
	    System.out.println("Introduzca la base del rectángulo");
	    base = sc.nextDouble();
	    System.out.println("Introduzca la altura del rectángulo");
	    altura = sc.nextDouble();
	    diagonal = Math.sqrt(base*altura);
	    System.out.println("La diagonal del rectángulo es: "+diagonal);
    }    
}

