import java.util.Scanner;
import java.lang.Math;
public class Ejercicio2 {

    public static void main(String[] args) {

      	Scanner sc = new Scanner(System.in);
	    System.out.println("Ejercicio 2");
	    int entero, decimal;                                            //Declaramos los números como enteros
	    System.out.println("Introduzca la parte entera del número");
	    entero = sc.nextInt();                                          //Introducimos el valor entero
	    System.out.println("Introduzca la parte decimal del número");
	    decimal = sc.nextInt();                                         //Introducimos el valor decimal
	    String cadena = entero+"."+decimal;                             //Unimos los número es una cadena separados por un punto
	    Double numero = Double.parseDouble(cadena);                     //Convertimos la cadena a double
	    System.out.println("El número introducido es el "+numero);
    }    
}

