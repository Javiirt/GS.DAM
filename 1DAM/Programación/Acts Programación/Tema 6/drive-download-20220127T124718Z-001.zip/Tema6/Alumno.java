
package Tema6;

import java.util.Scanner;

/*1. Implementa la clase alumno. Los atributos de un alumno serán: nombre, trimestre1, trimestre2 y trimestre3.
En nombre se guardará el nombre completo del alumno y los otros atributos guardarán la nota del alumno (con decimales)
de cada uno de los trimestres del curso.
Además de definir los atributos anteriores habrá que implementar los siguientes métodos:
a) Un constructor por defecto, el cual pedirá por teclado que se introduzca el nombre del alumno e inicializará las notas a -1.
b) Un constructor que reciba el nombre y las 3 notas.
c) Los métodos get, que devuelvan el valor de los atributos.
d) Los métodos set, que reciban el nuevo valor de los atributos.
e) Un método que devuelva la nota final del alumno. Esta nota será la media de las notas de los 3 trimestres, si alguna nota
sigue valiendo -1 la nota final será -1.*/

public class Alumno {
    Scanner entrada = new Scanner (System.in);
    private String nombre;
    private double trimestre1, trimestre2, trimestre3;
   
    //Constructor por defecto
    Alumno(){
        nombre = entrada.nextLine();
        trimestre1 = -1;
        trimestre2 = -1;
        trimestre3 = -1;
    }
   
    //Constructor por parámetros
    Alumno (String nombre, double trimestre1, double trimestre2, double trimestre3){
        this.nombre = nombre;
        this.trimestre1 = trimestre1;
        this.trimestre2 = trimestre2;
        this.trimestre3 = trimestre3;
    }
   
    //Métodos get
    String getNombre(){
        return nombre;
    }
   
    double getTrimestre1(){
        return trimestre1;
    }
   
    double getTrimestre2(){
        return trimestre2;
    }
   
    double getTrimestre3(){
        return trimestre3;
    }
   
    //Métodos set
    void setNombre(String nombre){
        this.nombre = nombre;
    }
   
    void setTrimestre1(double trimestre1){
        this.trimestre1 = trimestre1;
    }
   
    void setTrimestre2(double trimestre2){
        this.trimestre2 = trimestre2;
    }
   
    void setTrimestre3 (double trimestre3){
        this.trimestre3 = trimestre3;
    }
   
    //Devolver nota final    
    double NotaFinal(){
        double media;
        if(trimestre1 == -1 || trimestre2 == -1 || trimestre3 == -1){
            media = -1;
        } else {
            media = (trimestre1 + trimestre2 + trimestre3) / 3;
        }
        return media;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Introduce el número de alumnos");
        int nAlumnos = sc.nextInt();
        Alumno [] alumnos = new Alumno[nAlumnos];
        double sumaNotas = 0;
        int total=0;
        for(int i=0; i<alumnos.length;i++){
            alumnos[i] = new Alumno();
            System.out.println("Introduzca el nombre del Alumno");
            alumnos[i].setNombre(sc.nextLine());
            System.out.println("Introduzca la nota del trimestre 1");
            alumnos[i].setTrimestre1(sc.nextInt());
            System.out.println("Introduzca la nota del trimestre 2");
            alumnos[i].setTrimestre2(sc.nextInt());
            System.out.println("Introduzca la nota del trimestre 3");
            alumnos[i].setTrimestre3(sc.nextInt());
            
            if(alumnos[i].NotaFinal()!=-1.0){
                sumaNotas += alumnos[i].NotaFinal();
                total++;
            }
        }
        double notaMedia = sumaNotas/total;
        System.out.println("La nota media es: "+notaMedia);
    }
        
}
