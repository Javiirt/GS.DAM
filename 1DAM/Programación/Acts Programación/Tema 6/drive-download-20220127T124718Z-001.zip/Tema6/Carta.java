
package Tema6;
/**/
import java.util.Scanner;

public class Carta {
    private Scanner input;
    private int numero;
    private char palo;
    Scanner sc = new Scanner(System.in);

    public Carta(){
        numero = (int)(Math.random()*13+1);
        int azar = (int)(Math.random()*4);
        switch(azar){
            case 0: palo = 'c';
            break;
            case 1: palo = 'd';
            break;
            case 2: palo = 'p';
            break;
            case 3: palo = 't';
        }
        
    }
    public Carta(int numero,char palo){
        while(numero<1 || numero>13){
            System.out.println("Introduzca un número válido");
            numero = sc.nextInt();
        }
        while(palo!='c'|| palo!='p'||palo!='d'||palo!='t'){
            System.out.println("Introduzca un palo válido");
            palo = sc.next().charAt(0);
        }
        this.numero = numero;
        this.palo = palo;
    }

    public int getNumero() {
        return numero;
    }

    public char getPalo() {
        return palo;
    }

    public void setNumero(int numero) {
        while(numero<1 || numero>13){
            System.out.println("Introduzca un número válido");
            numero = sc.nextInt();
        }
        this.numero = numero;
    }

    public void setPalo(char palo) {
        while(palo!='c'|| palo!='p'||palo!='d'||palo!='t'){
            System.out.println("Introduzca un palo válido");
            palo = sc.next().charAt(0);
        }
        this.palo = palo;
    }
    public void mostrarCarta(){
        String cadenaPalo = "";
        switch(palo){
            case 'c': cadenaPalo = "corazones";
            break;
            case 'p': cadenaPalo = "picas";
            break;
            case 'd': cadenaPalo = "diamantes";
            break;
            case 't': cadenaPalo = "treboles";
        }
        switch(numero){
            case 1 : System.out.println("es el As de "+cadenaPalo);
            break;
            case 11:    System.out.println("es el Jack de "+cadenaPalo);
            break;
            case 12:    System.out.println("es la Reina de "+cadenaPalo);
            break;
            case 13:    System.out.println("es el Rey de "+cadenaPalo);
            break;
            default: System.out.println("es el "+numero+" de "+cadenaPalo);
        }
    }
    public  void cartaGanadora(Carta carta2){
        System.out.print("La carta ganadora  ");
        if(numero > carta2.getNumero()){
            mostrarCarta();
        } else if (numero == carta2.getNumero()){
            if(palo > carta2.getPalo()){
                mostrarCarta();
            }else{
                carta2.mostrarCarta();
            }
        }else{
            carta2.mostrarCarta();
        }
    }    
}

/*
Implementa la clase carta que pertenezca al paquete naipes. Los atributos de una carta
son palo (corazones, rombos, picas, tréboles) y numero (1-13).

Además de definir los atributos anteriores habrá que implementar los siguientes
métodos:

    a) Un constructor por defecto.

    b) Un constructor que reciba el palo y el número. Estos deberán ser válidos, si
    no se volverán a pedir por teclado.

    c) Los métodos devolver, que devuelvan el valor de los atributos.

    d) Los métodos establecer, que reciban el nuevo valor de los atributos. Estos
    deberán ser válidos, en caso contrario se volverán a pedir por teclado.

    e) Un método que muestre por pantalla el tipo de carta de que se trata. Si el
    número es 11, 12 o 13 se cambiará por Jota, Reina y Rey. Ejemplo:
        - Si se trata del 5 de corazones la salida será: 5 de corazones.
        - Si se trata del 12 de picas la salida será: Reina de picas.

    f) Un método cartaGanadora. Este método recibe una carta por parámetro y
    devolverá true si la carta que llama al método gana a la que se pasa por
    parámetro o es la misma. False en otro caso. La forma de determinar si una
    carta es ganadora es: Si tiene un número mayor, y en caso de empate el orden
    de palos ganadores será: corazones, picas, rombos, tréboles. Ejemplo:
    Carta.cartaGanadora(otraCarta)
    Carta= 5 corazones OtraCarta 9 rombos -> resultado: FALSE
    Carta= 11 corazones OtraCarta 11 rombos -> resultado: TRUE
    Carta= 7 picas OtraCarta 7 picas -> resultado: TRUE
*/