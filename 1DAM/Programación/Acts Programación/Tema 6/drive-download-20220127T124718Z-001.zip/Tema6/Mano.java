
package Tema6;

import java.util.Scanner;

public class Mano {
    int numeroCartas;
    Carta cartas[];
    Scanner sc = new Scanner(System.in);
    
    public Mano(){
        numeroCartas=3;
        cartas = new Carta[numeroCartas];
        for(int i= 0; i<cartas.length;i++){
            cartas[i]=new Carta();
        } 
    }
    
    public Mano(int numero){
        numeroCartas=numero;
        cartas = new Carta[numeroCartas];
        for(int i= 0; i<cartas.length;i++){
            cartas[i]=new Carta();
        } 
        
    }
    
    int getNumeroCarta(){
        return numeroCartas;
    }
    
    Carta getCarta(int posicion){
        return cartas[posicion];
    }
    
    void mostraCarta(int posicion){
        cartas[posicion].mostrarCarta();
    }
    
    void setCarta(int posicion, int numero, char palo){
        cartas[posicion].setNumero(numero);
        cartas[posicion].setPalo(palo);
    }
    
    void modificar(int posicion){
        System.out.println("Introduzca un número");
        int numero = sc.nextInt();
        cartas[posicion].setNumero(numero);
        System.out.println("Introduzca un palo");
        char palo = sc.next().charAt(0);
        cartas[posicion].setPalo(palo);
    }
    
    public static void main(String[]args){
        Mano mano1 = new Mano();
        Mano mano2 = new Mano();
        
        System.out.println("Cartas del jugador 1 :");
        for(int i=0; i<mano1.getNumeroCarta();i++){
            mano1.mostraCarta(i);
        }
        System.out.println();
          
        System.out.println("Cartas del jugador 2 :");
        for(int i=0; i<mano2.getNumeroCarta();i++){
            mano2.mostraCarta(i);
        }
        System.out.println();
        
        
        for(int i=0; i<mano1.getNumeroCarta();i++){
            mano1.getCarta(i).cartaGanadora(mano2.getCarta(i));
        }
    }
}

/*
3. Implementa la clase mano que pertenezca al paquete naipes y que use la clase carta.
Esta clase tendrá 2 atributos: Un array de cartas y el número de cartas. Además de este
atributo, la clase mano tendrá los siguientes métodos:

    a) Un constructor por defecto. En este constructor se inicializará el atributo
    número de cartas a 3.

    b) Un constructor que reciba por parámetro el número de cartas.

    c) Un método get que devuelva el número de cartas de la mano.

    d) Un método getCarta que reciba una posición y devuelva la Carta indicada.

    e) Un método mostrarCarta que reciba una posición y muestre la carta indicada.

    f) Un método setCarta que reciba una posición, el número y el palo de esa carta
    y los modifique.

    g) Un método modificar que reciba una posición, y pida por teclado el número y
    el palo de una carta y lo almacene en esa posición.

    h) Un método mano ganadora que reciba una mano y que muestre por pantalla
    ambas manos y quien es el ganador o si hay empate. Para ver quién es el
    ganador, se comprueban una a una las cartas de las 2 manos y el que tenga
    más cartas ganadoras será el ganador.

    i) Un método main en el que se creen dos objetos mano se inicialicen y se
    compruebe quien es el ganador. ¿influye que el main esté en la clase mano o
    en una clase externa?
*/