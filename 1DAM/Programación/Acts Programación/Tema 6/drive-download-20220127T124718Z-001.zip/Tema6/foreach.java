
package Tema6;
import java.util.Scanner;
public class foreach {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double[] nota = new double[4];
        System.out.println("Para calcular la nota media necesito saber la nota de cada uno de tus examenes");
        for(int i=0; i<4;i++){
            System.out.println("Nota del examen nº "+(i+1)+": ");
            nota[i]= sc.nextDouble();
        }
        System.out.println("Tus notas son: ");
        double suma=0;
        for(double n : nota){
            System.out.print(n + " ");
            suma+=n;            
        }
        System.out.println("\nLa media es "+suma/4);
    }        
}
