/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciosVectores;

import java.util.Scanner;

public class vector1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int []vector = {4,5,6,7};
        for(int i=0; i<vector.length;i++){
            System.out.println(vector[i]);
        }
    }
}
