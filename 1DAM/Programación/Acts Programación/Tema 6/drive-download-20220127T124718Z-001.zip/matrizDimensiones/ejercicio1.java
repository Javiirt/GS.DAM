
package matrizDimensiones;

import java.util.Scanner;



public class ejercicio1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Introduzca el número de filas");
        int filas = sc.nextInt();
        System.out.println("Introduzca el número de columnas");
        int columnas = sc.nextInt();
        
        int [][] tablero=new int [filas][columnas];
       
        for(int i=0;i<tablero.length;i++){
            for(int j =0; j<tablero[i].length;j++){
                tablero[i][j]=(int)(Math.random()*100+1);
            }
        }       
        
        for (int i=0;i<tablero.length;i++){
           for(int j =0; j<tablero[i].length;j++){
             System.out.print("valor ("+i+","+j+"): "+tablero[i][j]+"   ");
           }
           System.out.println();
        }
    }
}


/*
1. Desarrolla una aplicación que cree una matriz. El número de filas y columnas de la
matriz se pedirán al usuario. La matriz se inicializará con números aleatorios entre 1 y
100 y se mostrará su contenido por pantalla.
*/