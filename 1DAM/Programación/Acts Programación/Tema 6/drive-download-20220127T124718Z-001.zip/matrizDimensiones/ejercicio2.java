
package matrizDimensiones;

import java.util.Scanner;

public class ejercicio2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int [][] tablero=new int [10][10];
       
        for(int i=0;i<tablero.length;i++){
            for(int j =0; j<tablero[i].length;j++){
                tablero[i][j]=(int)(Math.random()*100+1);
            }
        }   
        System.out.println("Introduzca el número que buscas");
        int numero = sc.nextInt();
        boolean existe= false;
        for(int i=0;i<tablero.length && existe==false;i++){
            for(int j =0; j<tablero[i].length && existe==false;j++){
                if(tablero[i][j]==numero){
                    System.out.println("El numero existe en la posición ("+i+","+j+")");
                    existe = true;
                }
            }
        } 
        if(!existe){
            System.out.println("El numero buscado no existe");
        }
        
        for (int i=0;i<tablero.length;i++){
           for(int j =0; j<tablero[i].length;j++){
             System.out.print("valor ("+i+","+j+"): "+tablero[i][j]+"   ");
           }
           System.out.println();
        }
    }
}


/*
2. Desarrolla una aplicación que genere una matriz de 10 por 10 enteros aleatorios.
Después se pedirá un entero al usuario. Se buscará dicho entero en la matriz. Si este se
encuentra en ella se indicará cual es su posición (fil, col) y después se mostrará la
matriz para comprobarlo. En caso contrario se indicará que este no se encuentra en la
matriz.
*/