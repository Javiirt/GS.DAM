
package matrizDimensiones;

import java.util.Scanner;


public class ejercicio3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduzca el número de filas de las matrices");
        int filas = sc.nextInt();
        System.out.println("Introduzca el número de columnas de las matrices");
        int columnas = sc.nextInt();

        int [][] matriz1=new int [filas][columnas];
        int [][] matriz2=new int [filas][columnas];
        
        for(int i=0;i<matriz1.length;i++){
            for(int j =0; j<matriz1[i].length;j++){
                matriz1[i][j]=(int)(Math.random()*100+1);
                matriz2[i][j]=(int)(Math.random()*100+1);
            }
        }
        System.out.println("Matriz 1:");
        for (int i=0;i<matriz1.length;i++){
           for(int j =0; j<matriz1[i].length;j++){
             System.out.print("valor ("+i+","+j+"): "+matriz1[i][j]+"   ");
           }
           System.out.println();
        }
        System.out.println("Matriz 2:");
        for (int i=0;i<matriz2.length;i++){
           for(int j =0; j<matriz2[i].length;j++){
             System.out.print("valor ("+i+","+j+"): "+matriz2[i][j]+"   ");
           }
           System.out.println();
        }
        
        System.out.println("La suma de las dos matrices es:");
        for (int i=0;i<matriz1.length;i++){
           for(int j =0; j<matriz1[i].length;j++){
             System.out.print("valor ("+i+","+j+"): "+(matriz1[i][j]+matriz2[i][j])+"   ");
           }
           System.out.println();
        }
    }
}


/*
3. Desarrolla una aplicación que pida al usuario el tamaño de dos matrices. Las rellene
con números aleatorios. Las sume y muestre el resultado por pantalla.
*/