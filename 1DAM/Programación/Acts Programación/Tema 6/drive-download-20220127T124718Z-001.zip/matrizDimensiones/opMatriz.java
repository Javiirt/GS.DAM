
package matrizDimensiones;

public class opMatriz {
    
}


/*
4. Implementa la clase opMatriz. El único atributo de la clase es matriz que será un array
de dos dimensiones.

Además de definir los atributos anteriores habrá que implementar los siguientes
métodos:

a) Un constructor por defecto que cree una matriz de 3x3.
b) Un constructor que reciba el número de filas y de columnas y rellene la
matriz con números aleatorios.
c) Un método mostrar matriz que muestre por pantalla el contenido de la
matriz.
d) Un método modificar que reciba una fila una columna y el nuevo valor a
introducir.
e) Un método devolver que devuelva el array que contiene la matriz.


f) Un método sumar, que reciba un array de dos dimensiones y no devuelva
nada. Este método deberá comprobar que el tamaño de la matriz recibida es
igual a la que llama al método, si no son iguales mostrará un error, si son
iguales las sumará y las mostrará por pantalla.
g) Un método restar, que reciba un array de dos dimensiones y no devuelva
nada. Este método deberá comprobar que el tamaño de la matriz recibida es
igual a la que llama al método, si no son iguales mostrará un error, si son
iguales las restará.
h) Una clase ejecutar que utilice a la clase Opmatriz que cree dos matrices, la
primera se creará con el constructor por defecto y se rellenará con números
aleatorios usando el método modificar. La otra matriz se creará con el otro
constructor. Se mostrarán ambas matrices, y después se sumarán y se
mostrará el resultado y por último se restarán y se volverá a mostrar el
resultado.
*/