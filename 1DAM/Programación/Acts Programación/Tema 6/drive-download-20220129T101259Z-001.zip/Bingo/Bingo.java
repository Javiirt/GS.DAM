
package Bingo;

import java.util.Scanner;

public class Bingo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Carton jugador1 = new Carton();
        Carton jugador2 = new Carton();
        int ganadorLinea=0;
        int ganadorBingo=0;
        boolean linea = false;
        do{
            System.out.println("Pulse una tecla para generar un número");
            sc.next().charAt(0);
            int numero = (int)(Math.random()*20)+1;
            System.out.println("Ha salido el "+numero);
            
            jugador1.borrarNumero(numero);
            jugador2.borrarNumero(numero);
            
            System.out.println("Cartón del jugador 1\n");
            jugador1.mostrarCarton();
            System.out.println("Cartón del jugador 2\n");
            jugador2.mostrarCarton();
            
            if(jugador1.linea()==true && linea==false){
                System.out.println("================================\n"
                                 + "El jugador 1 ha conseguido línea\n"
                                 + "================================");
                ganadorLinea=1;
                linea = true;
            }else if(jugador2.linea()==true && linea==false){
                
                ganadorLinea=2;
                linea = true;
            }
            if(linea){
            System.out.println("================================\n"
                                 + "El jugador "+ganadorLinea+" ha conseguido línea\n"
                                 + "================================");
            }
            
            if(jugador1.bingo()==true){
                System.out.println("================================\n"
                                 + "El jugador 1 ha conseguido bingo\n"
                                 + "================================");
                ganadorBingo=1;
            }else if(jugador2.bingo()==true){
                System.out.println("================================\n"
                                 + "El jugador 2 ha conseguido bingo\n"
                                 + "================================");
                ganadorBingo=2;
            }
            
        }while(jugador1.bingo()==false && jugador2.bingo()==false);
        System.out.println("La partida ha terminado\n"
                        + "El ganador es: EL JUGADOR "+ganadorBingo+"\n"
                        + "El primero en conseguir línea fue el jugador "+ganadorLinea);
    }
}
