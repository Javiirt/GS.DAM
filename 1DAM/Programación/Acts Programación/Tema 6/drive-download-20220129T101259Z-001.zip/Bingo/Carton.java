
package Bingo;

public class Carton {
    int carton[][];
    
    Carton(){
        carton = new int[3][4];
        for(int i= 0; i<carton.length;i++){
            for(int j= 0; j<carton[i].length;j++){
                int numero = 0;
                do{
                    numero = (int)(Math.random()*20)+1;
                }while(existe(numero));
                carton[i][j]=numero;
            } 
        } 
    }
    
    private boolean existe(int numero){
        boolean existe= false;
         for(int i= 0; i<carton.length;i++){
            for(int j= 0; j<carton[i].length;j++){
                if(carton[i][j]==numero){
                    return true;
                }                
            } 
        } 
        return existe;
    }
   
    
    void borrarNumero(int numero){
        for(int i= 0; i<carton.length;i++){
            for(int j= 0; j<carton[i].length;j++){
                if(carton[i][j]==numero){
                    carton[i][j]=0;
                }
            } 
        } 
    }
    void mostrarCarton(){
        for(int i= 0; i<carton.length;i++){
            for(int j= 0; j<carton[i].length;j++){
                if(carton[i][j]==0){
                    System.out.print("\033[1;31m X\t");
                }else{
                    System.out.print("\033[0;30m"+carton[i][j]+"\t");
                }
            } 
            System.out.println("\033[0;30m");
        } 
    }
    
    boolean bingo(){
        boolean borradoBingo = true;
        for(int i= 0; i<carton.length ;i++){
            for(int j= 0; j<carton[i].length;j++){
                if(carton[i][j]!=0){
                    borradoBingo = false;
                }
            } 
        } 
        return borradoBingo;
    }
    boolean linea(){
        boolean borradoLinea = true;
        for(int i= 0; i<carton.length;i++){
            borradoLinea = true;
            for(int j= 0; j<carton[i].length;j++){
                if(carton[i][j]!=0){
                    borradoLinea = false;
                }
            }
            if(borradoLinea){
                break;
            }
        } 
        return borradoLinea;
    }
}
