
package bidimensionales;

import java.util.Scanner;

public class Notas {
    int matrizNotas[][];
    String[] nombreAsignatura;
    String[] nombreAlumnos;
    
    Notas(){        
        nombreAsignatura = new String[6];
        nombreAlumnos = new String[30];        
        matrizNotas= new int[30][6];
    }
    
    Notas(int alumnos, int asignaturas){        
        nombreAsignatura = new String[asignaturas];
        nombreAlumnos = new String[alumnos];        
        matrizNotas= new int[alumnos][asignaturas];
    }
    
    void setAsignatura (int posicion, String nuevoNombreAsignatura){
        nombreAsignatura[posicion]=nuevoNombreAsignatura;
    }
    void setAlumno (int posicion, String nuevoNombreAsignatura){
        nombreAlumnos[posicion]=nuevoNombreAsignatura;
    }
    void setNotaAlumnoAsignatura (int alumno, int asignatura,int nota){
        matrizNotas[asignatura][alumno]=nota;
    }
    
    int getNotaAlumnoAsignatura (int posicionAlumno, int posicionAsignatura){
        return matrizNotas[posicionAsignatura][posicionAlumno];
    }
    
    int[] getNotasAlumno(int posicion){
        int[] notas = new int[matrizNotas.length];
        for(int i=0; i<notas.length;i++){
            notas[i]=matrizNotas[i][posicion];
        }
        return notas;
    }
    
    int[] getNotasAlumno(String nombre){
        int[] notas = new int[matrizNotas.length];
        for(int i=0; i<nombreAlumnos.length;i++){
            if(nombreAlumnos[i]==nombre){
                for(int j=0; j<notas.length;j++){
                    notas[j]=matrizNotas[j][i];
                }
            }
        }
        return notas;
    }
    
    int[] getNotasAsignatura(int posicion){
        int[] notas = new int[matrizNotas[posicion].length];
        for(int i=0; i<notas.length;i++){
            notas[i]=matrizNotas[posicion][i];
        }
        return notas;
    }
    
    int[] getNotasAsignatura(String nombre){
        int[] notas = new int[matrizNotas[0].length];
        for(int i=0; i<nombreAsignatura.length;i++){
            if(nombreAsignatura[i]==nombre){
                for(int j=0; j<notas.length;j++){
                    notas[j]=matrizNotas[i][j];
                }
            }
        }
        return notas;
    }
    
    int suspensosAlumnos(int posicion){
        int suspensos=0;
        for(int i=0; i<matrizNotas.length;i++){
            if(matrizNotas[i][posicion]<5){
                suspensos++;
            }
        }
        return suspensos;
    }
    
    int suspensosAsignatura(int posicion){
        int suspensos=0;
        for(int i=0; i<matrizNotas[posicion].length;i++){
            if(matrizNotas[posicion][i]<5){
                suspensos++;
            }
        }
        return suspensos;
    }
    
    double mediaAlumno(int posicion){
        double media=0;
        for(int i=0; i<matrizNotas.length;i++){
            media+=matrizNotas[i][posicion];
        }
        media /=matrizNotas.length;
        return media;
    }
    
    double mediaAsignatura(int posicion){
        double media=0;
        for(int i=0; i<matrizNotas[posicion].length;i++){
            media+=matrizNotas[posicion][i];
        }
        media /=matrizNotas.length;
        return media;
    }
    
    void mostrarBoletinClase(){
        for(int i=0; i<nombreAlumnos.length;i++){
            System.out.print(nombreAlumnos[i]+"\t");
            for(int j=0; j<matrizNotas.length;j++){
                System.out.print(matrizNotas[j][i]+"\t");
            }
            System.out.println("\n");
        }
        for(int i=0; i<nombreAsignatura.length;i++){
            System.out.print((i+1)+" "+nombreAsignatura[i]);
        }
    }
    
    void mostrarBoletinAlumno(int posicion){
        System.out.println(nombreAlumnos[posicion]);
        for(int i=0; i<matrizNotas.length;i++){
            
            System.out.println(nombreAsignatura[i]+" "+matrizNotas[i][posicion]);
        }
        System.out.println("Total suspensos: "+suspensosAlumnos(posicion));
        System.out.println("Nota media: "+mediaAlumno(posicion));
    }
    
    void mostrarResumenAsignatura(int posicion){
        System.out.println(nombreAsignatura[posicion]);
        for(int i=0; i<matrizNotas[posicion].length;i++){
            
            System.out.println(nombreAlumnos[i]+" "+matrizNotas[posicion][i]);
        }
        System.out.println("Total suspensos: "+suspensosAsignatura(posicion));
        System.out.println("Nota media: "+mediaAsignatura(posicion));
    }
    
    int[][] traspuesta(){
        int[][] traspuesta= new int[matrizNotas[0].length][matrizNotas.length];
        for(int i= 0; i<matrizNotas.length;i++){
            for(int j= 0; j<matrizNotas[i].length;j++){
                traspuesta[j][i]=matrizNotas[i][j];
            }
        }
        return traspuesta;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Notas clase = new Notas();
        
    }
}
